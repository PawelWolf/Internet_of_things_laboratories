#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <RTClib.h>

#define OLED_ADDR 0x3C
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1

#define JOY_X A1
#define JOY_Y A0
#define JOY_PIN 2

#define BUZZER_PIN 8

#define SNAKE_SIZE 4
#define MAX_SNAKE_SIZE 100

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
RTC_DS1307 rtc;

// Wąż
int snakeX[MAX_SNAKE_SIZE];
int snakeY[MAX_SNAKE_SIZE];
int snakeSize = SNAKE_SIZE;
int snakeDir = 1; // 0=UP,1=RIGHT,2=DOWN,3=LEFT
int foodX = 1, foodY = 1;

bool gameOver = false;
bool paused = false;

// Wyniki
int score = 0;
int totalScore = 0;

// Debounce
bool lastButton = HIGH;
unsigned long lastDebounce = 0;
const unsigned long debounceDelay = 200;

// ---------------- RTC – wyświetlanie daty i czasu ----------------

void showDateTime(int x, int y) {
  DateTime now = rtc.now();
  display.setCursor(x, y);

  if (now.day() < 10) display.print('0');
  display.print(now.day());
  display.print('.');

  if (now.month() < 10) display.print('0');
  display.print(now.month());
  display.print('.');
  display.print(now.year());

  display.print(" ");

  if (now.hour() < 10) display.print('0');
  display.print(now.hour());
  display.print(':');

  if (now.minute() < 10) display.print('0');
  display.print(now.minute());
}

// ---------------- Ekran startowy ----------------

void showStartScreen() {
  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setTextSize(1);

  display.setCursor(10, 5);
  display.println("SNAKE GAME");

  display.setCursor(0, 20);
  display.println("Start time:");
  showDateTime(0, 30);

  display.setCursor(0, 50);
  display.print("Score total: ");
  display.print(totalScore);

  display.display();

  // Czekaj na kliknięcie
  while (digitalRead(JOY_PIN) == HIGH) {}
  delay(300);
}

// ---------------- Inicjalizacja węża ----------------

void initSnake() {
  snakeSize = SNAKE_SIZE;
  snakeDir = 1;
  score = 0;
  gameOver = false;
  paused = false;

  int startX = SCREEN_WIDTH / 2;
  int startY = SCREEN_HEIGHT / 2;

  for (int i = 0; i < snakeSize; i++) {
    snakeX[i] = startX - i * 4;
    snakeY[i] = startY;
  }

  foodX = random(0, SCREEN_WIDTH / 4) * 4;
  foodY = random(0, SCREEN_HEIGHT / 4) * 4;
}

// ---------------- Logika węża ----------------

void updateSnake() {
  int newHeadX = snakeX[0];
  int newHeadY = snakeY[0];

  switch (snakeDir) {
    case 0: newHeadY -= 2; break;
    case 1: newHeadX += 2; break;
    case 2: newHeadY += 2; break;
    case 3: newHeadX -= 2; break;
  }

  if (newHeadX < 0 || newHeadX >= SCREEN_WIDTH || newHeadY < 0 || newHeadY >= SCREEN_HEIGHT) {
    gameOver = true;
    return;
  }

  for (int i = 1; i < snakeSize; i++) {
    if (newHeadX == snakeX[i] && newHeadY == snakeY[i]) {
      gameOver = true;
      return;
    }
  }

  if (newHeadX == foodX && newHeadY == foodY) {
    snakeSize++;
    if (snakeSize > MAX_SNAKE_SIZE) snakeSize = MAX_SNAKE_SIZE;

    score ++;

    foodX = random(0, SCREEN_WIDTH / 4) * 4;
    foodY = random(0, SCREEN_HEIGHT / 4) * 4;

    digitalWrite(BUZZER_PIN, HIGH);
    delay(80);
    digitalWrite(BUZZER_PIN, LOW);

  } else {
    for (int i = snakeSize - 1; i > 0; i--) {
      snakeX[i] = snakeX[i - 1];
      snakeY[i] = snakeY[i - 1];
    }
  }

  snakeX[0] = newHeadX;
  snakeY[0] = newHeadY;
}

// ---------------- Rysowanie gry ----------------

void drawGame() {
  display.clearDisplay();

  for (int i = 0; i < snakeSize; i++) {
    display.fillRect(snakeX[i], snakeY[i], 4, 4, WHITE);
  }

  display.fillRect(foodX, foodY, 4, 4, WHITE);

  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print("Score: ");
  display.print(score);

  display.display();
}

// ---------------- Pauza ----------------

void showPause() {
  display.clearDisplay();
  display.setTextSize(2);
  display.setCursor(30, 20);
  display.println("PAUSE");
  display.display();
}

// ---------------- Game Over ----------------

void showGameOver() {
  display.clearDisplay();
  display.setTextSize(2);
  display.setCursor(10, 0);
  display.println("GAME OVER");

  display.setTextSize(1);
  display.setCursor(0, 25);
  display.print("Score: ");
  display.println(score);

  display.setCursor(0, 35);
  display.print("Total: ");
  display.println(totalScore);

  display.setCursor(0, 50);
  showDateTime(0, 50);

  display.display();
}

// ---------------- Setup ----------------

void setup() {
  randomSeed(analogRead(A0));

  pinMode(JOY_X, INPUT);
  pinMode(JOY_Y, INPUT);
  pinMode(JOY_PIN, INPUT_PULLUP);
  pinMode(BUZZER_PIN, OUTPUT);

  Wire.begin();
  rtc.begin();

  display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR);
  display.clearDisplay();

  showStartScreen();
  initSnake();
}

// ---------------- Loop ----------------

void loop() {
  // Obsługa przycisku joysticka (pauza)
  bool reading = digitalRead(JOY_PIN);

  if (reading != lastButton && (millis() - lastDebounce) > debounceDelay) {
    lastDebounce = millis();

    if (reading == LOW) {
      paused = !paused;
      if (paused) showPause();
    }
  }
  lastButton = reading;

  if (paused) return;

  updateSnake();
  drawGame();

  int joyX = analogRead(JOY_X);
  int joyY = analogRead(JOY_Y);

  if (joyX < 100 && snakeDir != 3) snakeDir = 1;
  else if (joyX > 900 && snakeDir != 1) snakeDir = 3;
  else if (joyY < 100 && snakeDir != 0) snakeDir = 2;
  else if (joyY > 900 && snakeDir != 2) snakeDir = 0;

  delay(80);

  if (gameOver) {
    totalScore += score;

    digitalWrite(BUZZER_PIN, HIGH);
    delay(300);
    digitalWrite(BUZZER_PIN, LOW);

    showGameOver();

    while (digitalRead(JOY_PIN) == HIGH) {}
    delay(300);

    showStartScreen();
    initSnake();
  }
}
